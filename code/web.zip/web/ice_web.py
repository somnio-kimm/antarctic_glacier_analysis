import os
from flask import Flask, render_template, request, url_for, session, redirect
from datetime import datetime
from PIL import Image
import matplotlib
matplotlib.use('Agg')  # GUI 충돌 방지용
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

app = Flask(__name__)
app.secret_key = 'replace-with-a-secure-key'  # 세션에 날짜 저장용

# 디렉토리 설정
BASE_DIR = os.path.join(os.getcwd(), 'web')
IMAGE_DIR = os.path.join(BASE_DIR, 'static', 'images')
GRAPH_DIR = os.path.join(BASE_DIR, 'static', 'graphs')

os.makedirs(IMAGE_DIR, exist_ok=True)
os.makedirs(GRAPH_DIR, exist_ok=True)

print(f"Image Directory: {IMAGE_DIR}")
print(f"Graph Directory: {GRAPH_DIR}")

# 예측 이미지 시작 시점
PRED_START_DATE = datetime(2025, 5, 1)

def get_real_image_path(year, month):
    fname = f"img_grey_{year}{month:02d}.png"
    return os.path.join(IMAGE_DIR, fname)

def get_pred_image_path(year, month):
    target = datetime(year, month, 1)
    delta_months = (target.year - PRED_START_DATE.year) * 12 + (target.month - PRED_START_DATE.month)
    if 0 <= delta_months <= 23:
        fname = f"pred_{delta_months:02d}.png"
        return os.path.join(IMAGE_DIR, fname)
    return None

def generate_change_graph(year, month):
    image_files = sorted([f for f in os.listdir(IMAGE_DIR) if f.startswith('img_grey_')],
                         key=lambda x: datetime.strptime(x.split('_')[-1].split('.')[0], "%Y%m"))
    dates = [datetime.strptime(f.split('_')[-1].split('.')[0], "%Y%m") for f in image_files]

    areas = []
    for file in image_files:
        img = Image.open(os.path.join(IMAGE_DIR, file)).convert('L').resize((512, 512))
        img_arr = np.array(img) / 255.0
        glacier_area = np.sum(img_arr > 0.5)
        areas.append(glacier_area)

    df = pd.DataFrame({'date': dates, 'area': areas})
    df['rolling'] = df['area'].rolling(window=12).mean()
    df = df.dropna()
    df['rate'] = df['rolling'].pct_change()
    df = df.dropna()

    target_date = datetime(year, month, 1)
    recent = df[df['date'] <= target_date].tail(5)

    if recent.empty:
        return None

    # 그래프
    plt.figure(figsize=(6, 4))
    plt.bar([d.strftime('%Y-%m') for d in recent['date']], recent['rate'] * 100)
    plt.ylabel('Change Rate (%)')
    plt.title('Glacier Area Change Rate')
    plt.xticks(rotation=45)
    plt.tight_layout()

    graph_path = os.path.join(GRAPH_DIR, f"rate_{year}{month:02d}.png")
    plt.savefig(graph_path)
    plt.close()
    return graph_path

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/result', methods=['POST'])
def result_post():
    year = int(request.form['year'])
    month = int(request.form['month'])
    session['year'] = year
    session['month'] = month
    return redirect(url_for('result_get'))

@app.route('/result')
def result_get():
    year = session.get('year')
    month = session.get('month')

    if not year or not month:
        return redirect(url_for('index'))

    real_path = get_real_image_path(year, month)
    pred_path = get_pred_image_path(year, month)
    graph_path = generate_change_graph(year, month)

    real_image = url_for('static', filename=f'images/{os.path.basename(real_path)}') if os.path.exists(real_path) else None
    pred_image = url_for('static', filename=f'images/{os.path.basename(pred_path)}') if pred_path and os.path.exists(pred_path) else None
    graph_image = url_for('static', filename=f'graphs/{os.path.basename(graph_path)}') if graph_path and os.path.exists(graph_path) else None

    # 미래 예측 여부 및 예측된 변화 추적
    is_prediction = False
    trend = None

    # 예측 이미지일 때는 예측된 변화량을 계산해서 trend에 할당
    if pred_image:
        is_prediction = True
        trend = "감소"  # 예시로 "감소"라는 값을 넘김. 실제로 예측된 변화량 계산 로직을 추가하면 됨

    return render_template('result.html', year=year, month=month,
                           real_image=real_image,
                           pred_image=pred_image,
                           graph_image=graph_image,
                           is_prediction=is_prediction,
                           trend=trend)  # is_prediction과 trend를 템플릿에 전달

if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)
